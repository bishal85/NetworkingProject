from chroma import collection

# Get all documents and metadata (ids are included in 'data' if needed)
results = collection.get(include=["documents", "metadatas"])

print("All documents in ChromaDB:")
for doc, meta in zip(results["documents"], results["metadatas"]):
    print(f"Document: {doc}")
    print(f"Metadata: {meta}")
    print("-" * 40)

