import os
import chromadb
from chromadb.config import Settings

BASE_DIR = "/home/bisha/soc-ai/mern-amazona-master/ai-service/chroma_db"

os.makedirs(BASE_DIR, exist_ok=True)

client = chromadb.PersistentClient(
    path=BASE_DIR,
    settings=Settings(
        anonymized_telemetry=False
    )
)

collection = client.get_or_create_collection("amazona")


print(f"📁 Chroma persist directory: {BASE_DIR}")

