from fastapi import FastAPI
from pydantic import BaseModel
from .chroma import collection  # your ChromaDB collection
from .embeddings import model   # your sentence transformer model
from .llm import generate_answer

app = FastAPI()

class ChatReq(BaseModel):
    message: str

@app.post("/chat")
def chat(req: ChatReq):
    try:
        query = req.message.strip().lower()

        # If user wants only the price
        if "only tell me the price" in query:
            product_name = query.replace("only tell me the price", "").strip()

            results = collection.get(include=["metadatas"])
            for meta_list in results["metadatas"]:
                for item in meta_list:
                    if isinstance(item, dict) and "name" in item:
                        if product_name in item["name"].lower():
                            return {"reply": f"${item['price']}"}

            return {"reply": "Product not found."}

        # General queries: get embedding + top doc
        query_emb = model.encode(req.message).tolist()
        results = collection.query(query_embeddings=[query_emb], n_results=1, include=["documents","metadatas"])

        # Safely extract document and metadata
        doc = results["documents"][0][0] if results["documents"] and results["documents"][0] else ""
        meta = results["metadatas"][0][0] if results["metadatas"] and results["metadatas"][0] else {}

        # Ensure meta is a dict
        if not isinstance(meta, dict):
            meta = {}

        prompt = f"""
Use only these facts:

Context:
{doc}
Price: {meta.get('price', 'N/A')}
Brand: {meta.get('brand', 'N/A')}
Category: {meta.get('category', 'N/A')}

User question:
{req.message}
"""
        answer = generate_answer(prompt)
        return {"reply": answer}

    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"reply": f"Internal error: {e}"}





