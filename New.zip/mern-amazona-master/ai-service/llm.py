import requests
from typing import Optional, List

OLLAMA_URL = "http://127.0.0.1:11434/api/chat"
MODEL = "gemma3:1b"

def generate_answer(prompt: str, stop: Optional[List[str]] = None) -> str:
    """
    Send a prompt to Ollama LLM and return the response.
    """
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False
    }

    try:
        res = requests.post(OLLAMA_URL, json=payload, timeout=120)
        res.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Ollama request failed: {e}")

    data = res.json()
    return data.get("message", {}).get("content", "").strip()

