from pymongo import MongoClient

MONGODB_URI="mongodb+srv://bishalsarker234_db_user:QytVHIw27vrEcLWD@cluster0.3rt0wib.mongodb.net/?appName=Cluster0"

client = MongoClient(MONGODB_URI)
db = client["test"]

products_col = db["products"]
orders_col = db["orders"]
