from .mongo import products_col
from .chroma import collection, client
from .embeddings import model

def sync_products():
    print("🚀 sync.py started")

    docs, ids, metadatas = [], [], []

    count = products_col.count_documents({})
    print(f"🧾 Products in MongoDB: {count}")

    if count == 0:
        print("❌ No products to sync")
        return

    for p in products_col.find():
        docs.append(
            f"Product {p['name']} by {p['brand']}. "
            f"Category: {p['category']}. "
            f"Price: {p['price']}. "
            f"Rating: {p.get('rating', 0)}."
        )

        ids.append(f"product-{p['_id']}")

        metadatas.append({
            "name": p["name"],
            "price": p["price"],
            "brand": p["brand"],
            "category": p["category"],
            "countInStock": p.get("countInStock", 0),
            "rating": p.get("rating", 0),
        })

    print("🧠 Encoding embeddings...")
    embeddings = model.encode(docs, batch_size=32)

    print("📥 Upserting into ChromaDB...")
    collection.upsert(
        documents=docs,
        embeddings=embeddings.tolist(),
        ids=ids,
        metadatas=metadatas,
    )

    

    print(f"✅ Synced {len(docs)} products to ChromaDB (persisted)")

if __name__ == "__main__":
    sync_products()


