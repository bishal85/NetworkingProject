from mongo import products_col, orders_col

print("Products in MongoDB Atlas:")
for p in products_col.find():
    print(p)

print("\nOrders in MongoDB Atlas:")
for o in orders_col.find():
    print(o)
