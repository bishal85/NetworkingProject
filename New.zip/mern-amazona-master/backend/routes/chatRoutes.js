import express from "express";
import axios from "axios";

const chatRouter = express.Router();

chatRouter.post("/", async (req, res) => {
  try {
    const { message } = req.body;

    const { data } = await axios.post(
      "http://localhost:8000/chat",
      { message }
    );

    res.send({ reply: data.reply });
  } catch (err) {
    res.status(500).send({ message: "Chatbot error" });
  }
});

export default chatRouter;
