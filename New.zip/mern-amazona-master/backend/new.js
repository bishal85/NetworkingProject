import dotenv from 'dotenv';
import mongoose from 'mongoose';
import axios from 'axios';
// Note: In ES Modules, you MUST include the .js extension for local files
import Product from './models/productModel.js'; 

dotenv.config();

const seedDatabase = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB...");

    // Clear existing products
    await Product.deleteMany({});
    console.log("Old products cleared.");

    // Fetch data from Fake Store API
    const response = await axios.get('https://fakestoreapi.com/products');
    const products = response.data;

    // Format data to match Basir's Amazona Schema
    const formattedProducts = products.map(p => ({
      name: p.title,
      slug: p.title.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, ''),
      category: p.category,
      image: p.image,
      price: p.price,
      countInStock: 10,
      brand: 'Generic',
      rating: 0,
      numReviews: 0,
      description: p.description,
    }));

    await Product.insertMany(formattedProducts);
    console.log("✅ 20 Products successfully added!");
    
    process.exit();
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
};

seedDatabase();
