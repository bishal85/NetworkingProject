import React, { useState } from "react";
import axios from "axios";

export default function ChatBot() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;

    setMessages([...messages, { from: "user", text: input }]);

    const { data } = await axios.post("/api/chat", {
      message: input,
    });

    setMessages((m) => [...m, { from: "bot", text: data.reply }]);
    setInput("");
  };

  return (
    <div style={{
      position: "fixed",
      bottom: 20,
      right: 20,
      width: 300,
      background: "#fff",
      padding: 10,
      borderRadius: 8
    }}>
      <div style={{ height: 200, overflowY: "auto" }}>
        {messages.map((m, i) => (
          <div key={i}>
            <b>{m.from}:</b> {m.text}
          </div>
        ))}
      </div>
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask something..."
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}
